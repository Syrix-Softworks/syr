
const socket = io();
console.log("Connected to server");
